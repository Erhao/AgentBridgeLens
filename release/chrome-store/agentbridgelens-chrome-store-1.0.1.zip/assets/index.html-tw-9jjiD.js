import{m as o}from"./panel-ui-PcmHKVmm.js";import"./config-Cbxrl1OW.js";o(document.getElementById("controls"));
