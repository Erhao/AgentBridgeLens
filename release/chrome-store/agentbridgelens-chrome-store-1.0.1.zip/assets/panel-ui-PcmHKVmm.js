import{D as q,a as A,s as B,g as O}from"./config-Cbxrl1OW.js";(function(){const n=document.createElement("link").relList;if(n&&n.supports&&n.supports("modulepreload"))return;for(const t of document.querySelectorAll('link[rel="modulepreload"]'))p(t);new MutationObserver(t=>{for(const o of t)if(o.type==="childList")for(const u of o.addedNodes)u.tagName==="LINK"&&u.rel==="modulepreload"&&p(u)}).observe(document,{childList:!0,subtree:!0});function d(t){const o={};return t.integrity&&(o.integrity=t.integrity),t.referrerPolicy&&(o.referrerPolicy=t.referrerPolicy),t.crossOrigin==="use-credentials"?o.credentials="include":t.crossOrigin==="anonymous"?o.credentials="omit":o.credentials="same-origin",o}function p(t){if(t.ep)return;t.ep=!0;const o=d(t);fetch(t.href,o)}})();const H=`
  .bl-h1 { font-size: 14px; margin: 0 0 10px; }
  .status { font-size: 12px; padding: 6px 8px; border-radius: 6px; margin-bottom: 12px; background: #f0f2f5; white-space: pre-line; overflow-wrap: anywhere; }
  .status.ok { background: #e3f9e5; color: #207227; }
  .status.bad { background: #fff0f0; color: #ab1c1c; }
  .bl label { display: block; font-size: 12px; margin-bottom: 8px; }
  .bl input { width: 100%; box-sizing: border-box; padding: 5px 6px; margin-top: 3px; border: 1px solid #cbd2d9; border-radius: 5px; font-size: 13px; }
  #bl-save { width: 100%; padding: 7px; margin-top: 4px; border: none; border-radius: 6px; background: #4a90d9; color: #fff; font-size: 13px; cursor: pointer; }
  #bl-save:hover { background: #3a7bc0; }
  .bl .bl-privacy { font-size: 12px; line-height: 1.5; background: #eef4fb; padding: 8px; border-radius: 6px; margin-bottom: 10px; }
  .bl .bl-consent { display: flex; align-items: flex-start; gap: 6px; margin: 8px 0; }
  .bl .bl-consent input { width: auto; margin-top: 3px; }
  .bl .bl-privacy a { color: #2d6fd6; }
  .bl details { margin-bottom: 6px; }
  .bl summary { cursor: pointer; font-size: 12px; color: #4a90d9; user-select: none; }
  .bl hr { border: none; border-top: 1px solid #eef1f4; margin: 10px 0; }
  .bl-h2 { font-size: 12px; text-transform: uppercase; letter-spacing: 0.04em; color: #7b8794; margin: 0 0 6px; display: flex; align-items: center; justify-content: space-between; }
  #bl-clear-all { text-transform: none; letter-spacing: 0; background: none; border: none; color: #4a90d9; cursor: pointer; font-size: 11px; padding: 0; }
  .bl-target { font-size: 12px; background: #eef4fb; border-radius: 6px; padding: 5px 8px; margin-bottom: 8px; word-break: break-all; }
  #bl-tablist { max-height: 440px; overflow: auto; border: 1px solid #eef1f4; border-radius: 6px; }
  .bl-tab { display: flex; align-items: center; gap: 6px; padding: 5px 6px; border-bottom: 1px solid #f3f5f7; font-size: 12px; }
  .bl-tab:last-child { border-bottom: none; }
  .bl-tab.is-target { background: #e3f9e5; }
  .bl-tab .meta { flex: 1; min-width: 0; }
  .bl-tab .t { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .bl-tab .u { color: #9aa5b1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .bl-tab button { width: auto; margin: 0; padding: 3px 7px; font-size: 11px; flex: 0 0 auto; border: none; border-radius: 4px; cursor: pointer; }
  .bl-tab .pin-btn { background: #4a90d9; color: #fff; }
  .bl-tab .unpin-btn { background: #9aa5b1; color: #fff; }
  .bl-tab select { flex: 0 0 auto; font-size: 11px; padding: 2px; border: 1px solid #cbd2d9; border-radius: 4px; max-width: 92px; }
`,M=`
  <h1 class="bl-h1">AgentBridgeLens</h1>
  <div id="bl-status" class="status">检查连接中…</div>
  <div class="bl-privacy">
    连接后，AI 可通过你配置的 Bridge 读取标签页信息、网页内容、截图、调试日志，并执行网页操作；启动录制后还可记录输入内容。数据会发送到 Bridge 及其连接的 AI 客户端，可能离开本机。请仅连接可信服务，并避免在敏感页面使用。
    <a href="/privacy.html" target="_blank" rel="noopener">隐私政策 / Privacy policy</a>
    <label class="bl-consent"><input id="bl-consent" type="checkbox" />我同意上述数据访问和传输，并启用 Bridge 连接</label>
    <button id="bl-apply-consent" type="button">应用授权设置</button>
  </div>
  <details id="bl-conn">
    <summary>连接设置（Host / Port / Token）</summary>
    <label>Host <input id="bl-host" type="text" placeholder="127.0.0.1" /></label>
    <label>Port <input id="bl-port" type="number" min="1" max="65535" placeholder="19222" /></label>
    <label>Token <span style="color:#7b8794">（跨机时必填）</span>
      <input id="bl-token" type="password" placeholder="BRIDGELENS_TOKEN" autocomplete="off" /></label>
    <button id="bl-save">保存并重连</button>
  </details>
  <hr />
  <h2 class="bl-h2">目标标签页 <button id="bl-clear-all">全部取消</button></h2>
  <div id="bl-target" class="bl-target">跟随当前激活标签页</div>
  <div id="bl-tablist"></div>
`;async function v(){const{targetTabIds:e}=await chrome.storage.session.get("targetTabIds");return Array.isArray(e)?e.filter(n=>typeof n=="number"):[]}async function k(e){await chrome.storage.session.set({targetTabIds:e})}async function D(){const{newTabPolicy:e}=await chrome.storage.local.get("newTabPolicy");return e==="follow"?"follow":"stay"}async function P(){const{tabPolicies:e}=await chrome.storage.session.get("tabPolicies");return e&&typeof e=="object"?e:{}}async function R(e,n){const d=await P();d[String(e)]=n,await chrome.storage.session.set({tabPolicies:d})}function _(e){if(!document.getElementById("bl-style")){const a=document.createElement("style");a.id="bl-style",a.textContent=H,document.head.appendChild(a)}e.classList.add("bl"),e.innerHTML=M;const n=e.querySelector("#bl-status"),d=e.querySelector("#bl-host"),p=e.querySelector("#bl-port"),t=e.querySelector("#bl-token"),o=e.querySelector("#bl-save"),u=e.querySelector("#bl-target"),C=e.querySelector("#bl-tablist"),S=e.querySelector("#bl-clear-all"),E=e.querySelector("#bl-consent"),I=e.querySelector("#bl-apply-consent");async function m(){const{bridgeConsent:a}=await chrome.storage.local.get("bridgeConsent");if(a!==!0){n.textContent="连接已暂停：请阅读数据说明，勾选并应用授权后再连接。",n.className="status";return}chrome.runtime.sendMessage({type:"bridgelens-get-status"},r=>{if(chrome.runtime.lastError||!r){n.textContent="状态未知",n.className="status";return}n.textContent=r.connected?`已连接 ${r.url}`:`未连接到桥接服务${r.url?`：${r.url}`:""}
请检查：运行 AI 的电脑上是否已启动 AgentBridgeLens 桥接服务；下方 Host / Port 是否指向该服务，Token 是否一致。跨电脑连接还需确认网络可达。`,n.className=r.connected?"status ok":"status bad"})}async function N(){const{host:a,port:r,token:g}=await O();d.value=a,p.value=String(r),t.value=g;const{bridgeConsent:x}=await chrome.storage.local.get("bridgeConsent");E.checked=x===!0}I.addEventListener("click",async()=>{await chrome.storage.local.set({bridgeConsent:E.checked}),await m()}),o.addEventListener("click",async()=>{const a=d.value.trim()||q,r=parseInt(p.value,10)||A,g=t.value.trim();await B({host:a,port:r,token:g}),n.textContent="已保存，重连中…",n.className="status",setTimeout(m,600)}),S.addEventListener("click",async()=>{await k([]),f()});async function f(){const a=await v(),r=await P(),g=await D(),x=await chrome.tabs.query({}),T=a.filter(l=>x.some(i=>i.id===l));u.textContent=T.length===0?"跟随当前激活标签页":`🎯 已固定 ${T.length} 个（无 tabId 调用时用最近活跃的那个）`,C.innerHTML="";for(const l of x){if(typeof l.id!="number")continue;const i=l.id,L=a.includes(i),b=document.createElement("div");b.className="bl-tab"+(L?" is-target":"");const h=document.createElement("div");h.className="meta";const w=document.createElement("div");w.className="t",w.textContent=l.title||"(无标题)";const y=document.createElement("div");y.className="u";try{y.textContent=l.url?new URL(l.url).host||l.url:""}catch{y.textContent=l.url||""}if(h.appendChild(w),h.appendChild(y),b.appendChild(h),L){const s=document.createElement("select");s.innerHTML='<option value="stay">不跟随</option><option value="follow">跟随新标签</option>',s.value=r[String(i)]??g,s.title="该目标页打开新标签时的处理",s.addEventListener("change",()=>R(i,s.value)),b.appendChild(s);const c=document.createElement("button");c.className="unpin-btn",c.textContent="取消",c.addEventListener("click",async()=>{await k((await v()).filter(z=>z!==i)),f()}),b.appendChild(c)}else{const s=document.createElement("button");s.className="pin-btn",s.textContent="设为目标",s.addEventListener("click",async()=>{const c=await v();c.includes(i)||c.push(i),await k(c),f()}),b.appendChild(s)}C.appendChild(b)}}N(),m(),f(),setInterval(m,2e3),setInterval(f,2e3)}export{_ as m};
