Chrome Web Store submission candidate, version 1.0.1. These files are stored on a Git candidate tag for review and upload preparation; they are not published in the Chrome Web Store.

Upload only agentbridgelens-chrome-store-1.0.1.zip as the extension package. The store-materials ZIP contains the icon, a real 1280×800 extension screenshot of the local demonstration page, listing text, privacy policy, reviewer instructions and browser verification report; it is not the extension package.

First use and upgrades to this candidate require explicit Bridge authorization from the popup or side panel. JavaScript debugging uses the Debugger API and may display Chrome's debugging banner.

Validation: TypeScript checks, Bridge and release tests, isolated Chromium tests for consent and revocation, page and DOM inspection, JavaScript debugging and cleanup, network capture, screenshots and visual annotations.

Public privacy policy: https://github.com/Erhao/AgentBridgeLens/blob/chrome-store-candidate-1.0.1-r2/docs/PRIVACY.md
Source: chrome-store-candidate-1.0.1-r2 (based on the existing 1.0.0 release baseline; concurrent multi-Bridge changes are not included).

Pending: developer-account login/registration/verification, contact information, review of dashboard privacy fields, and actual Chrome Web Store submission.

Confirmed public support email: zhangxinyu9702@gmail.com
